# Elasticsearch and Arkime Setup Guide

## **1. Install Elasticsearch**
```bash
wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add -
echo "deb https://artifacts.elastic.co/packages/7.x/apt stable main" | sudo tee /etc/apt/sources.list.d/elastic-7.x.list
sudo apt update
sudo apt install -y elasticsearch
```

## **2. Start and Enable Elasticsearch Service**
```bash
sudo systemctl start elasticsearch
sudo systemctl enable elasticsearch
```

## **3. Check Elasticsearch Status**
```bash
sudo systemctl status elasticsearch
```

## **4. Verify Elasticsearch is Running**
```bash
curl -X GET "localhost:9200"
```
Expected JSON response:
```json
{
  "name" : "your-hostname",
  "cluster_name" : "elasticsearch",
  "cluster_uuid" : "some-uuid",
  "version" : {
    "number" : "7.x.x"
  }
}
```

## **5. Install and Start Arkime**
### **Start Arkime Services**
```bash
sudo systemctl start arkimecapture
sudo systemctl start arkimeviewer
```

### **Enable Arkime on Boot**
```bash
sudo systemctl enable arkimecapture
sudo systemctl enable arkimeviewer
```

### **Check Arkime Status**
```bash
sudo systemctl status arkimecapture
sudo systemctl status arkimeviewer
```

## **6. Verify Arkime is Running**
Once the services are running, open your browser and go to:
```
http://localhost:8005
```

## **7. Troubleshooting**
### **Check Logs**
```bash
sudo journalctl -u elasticsearch --no-pager | tail -n 50
sudo journalctl -u arkimecapture --no-pager | tail -n 50
sudo journalctl -u arkimeviewer --no-pager | tail -n 50
```

### **Check Configuration Files**
```bash
sudo nano /opt/arkime/etc/config.ini
```
Ensure `ES_HOSTS` is correctly pointing to your Elasticsearch instance.

### **Restart Services if Needed**
```bash
sudo systemctl restart elasticsearch
sudo systemctl restart arkimecapture
sudo systemctl restart arkimeviewer
```

## **8. Additional Resources**
- Arkime Official Documentation: [https://arkime.com/](https://arkime.com/)
- Elasticsearch Official Docs: [https://www.elastic.co/guide/en/elasticsearch/reference/current/index.html](https://www.elastic.co/guide/en/elasticsearch/reference/current/index.html)
