![step1](001.png)
![step2](002.png)
![step3](004.png)
##If you already have a host at that ip it may not work and you will have to remove it**
![step4](003.png)

wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add -
echo "deb https://artifacts.elastic.co/packages/7.x/apt stable main" | sudo tee /etc/apt/sources.list.d/elastic-7.x.list
sudo apt update
sudo apt install -y elasticsearch

![step4](005.png)


**This will run on the following localhost:8005

https://www.youtube.com/watch?v=2Sy-v_YPP7I



----


![alt text](006.png)